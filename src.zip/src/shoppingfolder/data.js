export const Gents = {
    title: "Gents Fashion",
    image1: "assets/Men/1.jpg",
    image2: "assets/Men/2.jpg",
    image3: "assets/Men/3.jpg",
    image4: "assets/Men/4.jpg",
    image5: "assets/Men/5.jpg",
    image6: "assets/Men/6.jpg",
    price1: "559 INR",
    price2: "459 INR",
    price3: "659 INR",
    price4: "759 INR",
    price5: "859 INR",
    price6: "959 INR",

}
export const Ladies = {
    title: "Ladies Fashion",
    image1: "assets/Woman/1.jpg",
    image2: "assets/Woman/2.jpg",
    image3: "assets/Woman/3.jpg",
    image4: "assets/Woman/4.jpg",
    image5: "assets/Woman/5.jpg",
    image6: "assets/Woman/6.jpg",
    price1: "1559 INR",
    price2: "1459 INR",
    price3: "1659 INR",
    price4: "1759 INR",
    price3: "1859 INR",
    price4: "1959 INR",

}